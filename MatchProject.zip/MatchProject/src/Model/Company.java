package Model;
public class Company {
    public  int ID;
    public  String Name;
    public  String Industry;    
    public  String Email;
    public  String PhoneNumber;
    public  int LogInUserID;
}
