package Model;
public class QualifyingCompany {
    public  int ID;
    public  String Name;
    public  String Industry;    
    public  String ProjectName;
    public  String ProjectManagerName;
    public  String ProjectManagerEmail;
    public  String Requirement;    
    public  int LevelOfExperty;
}
