package Model;
public class QualifiedCandidate {
    public  int ID;
    public  String FirstName;
    public  String LastName;
    public  String Email;
    public  String CellPhone;
    public  String Qualification;
    public  int LevelOfExperience; 
}
