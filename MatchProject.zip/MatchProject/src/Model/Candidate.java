package Model;

import java.sql.Date;

public class Candidate {
    public  int UserType;
    public  int ID;
    public  String FirstName;
    public  String LastName;
    public  Date DOB;
    public  String Email;
    public  String CellPhone;
    public  int LogInUserID;
}
