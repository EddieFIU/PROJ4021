package Model;

public class CandidateQualification {
    public  int ID;
    public  String Qualification;
    public  int LevelOfExperience;    
    public  int CandidateID;
}
