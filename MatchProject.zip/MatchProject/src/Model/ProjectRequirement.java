package Model;

public class ProjectRequirement {
    public  int ID;
    public  String Requirement;
    public  int LevelofExperty;    
    public  int CompanyProjectID;
}
