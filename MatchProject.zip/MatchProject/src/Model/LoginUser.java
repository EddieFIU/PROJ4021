package Model;

public class LoginUser {
 
    public  int ID;
    public  String UserName;
    public  String Password;
    public  String UserType;
    public  java.sql.Date CreatedDateTime;
    public String CellPhone;
    public String Email;
    public String FirstName;
    public String LastName;
    public String Industry;
    public String DOB;
    public String getUserType() {
        return null;
    }

}
