package Model;
public class CompanyProject {
    public  int ID;
    public  String ProjectName;
    public  String ProjectManagerName;    
    public  String ProjectManagerEmail;
    public  int CompanyID;
}
