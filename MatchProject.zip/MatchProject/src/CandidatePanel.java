public class CandidatePanel {
    
}
